[![](https://raw.githubusercontent.com/agyto/EMAK/master/public/img/lgo.png)]
## Welcome to EMAK
EMAK adalah portal yang mewadahi ide kreatif perempuan dalam membuat produk kerajinan yang akan menarik investor untuk berinvestasi/berdonasi terhadap

##What it does
EMAK akan mewadahi kalangan kreatif maupun non kreatif perempuan yang membuat hasta karya dan menampilkannya di dalam EMAK baik dalam bahan yang diperlukan, alat, dan tahapan-tahapan di dalam membuat hasta karya atau disini kami menyebutnya proyek/project yang di unggah ke dalam EMAK. User yang disini sebagai watcher maupun donatur akan melihat hasta karya yang ditampilkan dan apabila user/donatur yang tertarik dapat mendonasikan sejumlah uang dengan jumlah tertentu yang telah disediakan dengan spesifikasi apabila mendonasi sekian akan menerima apa, dan seterusnya begiru juga terdapat donasi VIP yang nantinya dapat mengakuisi produk hasta karya yang dibuat dengan catatan investor akan mendanai seluruh produksi yang akan dilakukan dengan kesepakatan yang telah ditentukan.


### License
>BASED ON
> + The Laravel framework 5.0 [ is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT) ]
> + CSS 3
> + Bootstrap 3 Framework
> + Free template Peter Finlan [ http://www.peterfinlan.com/ ]
