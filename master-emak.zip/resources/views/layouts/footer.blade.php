<footer>
  <div class="container">
  	<div class="row">
        <h2><i class="fa fa-paper-plane"></i><span>EMAK : portal-nya perempuan kreatif indonesia!</span></h2>
      	<small>TENTANG KAMI | VISI | MISI | HUBUNGI KAMI</small>
      </div>
    </div>
</footer>